1. Choose the number of threads in the software
2.soft generates wallets ETH,ETC,Eth pov,XMR,LTC
and also selects a seed phrase for them from our database.
3. Leave the software to work for a day.
4. Search can take up to 1 hour! You might be very lucky!

For all questions, contact my telegram:
https://t.me/Blackzzz4